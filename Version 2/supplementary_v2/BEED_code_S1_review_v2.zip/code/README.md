# BEED provenance audit and leakage-aware benchmark — code and results

Reproducible pipeline for the paper *"Shortcuts and Temporal Leakage in the Bangalore EEG Epilepsy Dataset: a Provenance
Audit and Leakage-Aware Benchmark of Lightweight Seizure-Type Classifiers"* (prepared for NIELIT Bio-AI Conclave 2026, Track 5).

## Contents

| Path | Description |
|---|---|
| `run_all.py` | Single entry point; regenerates every result and figure |
| `src/beed/` | Package: `config`, `data` (loading, provenance matching, grouped/blocked splitters, purge), `features`, `models`, `deep`, `evaluation` (metrics, cluster bootstrap, corrected t-test, Friedman/Nemenyi), `experiments`, `plots` |
| `data/BEED_Data.csv` | BEED file from the UCI repository (doi:10.24432/C5K33B, CC BY 4.0) |
| `data/external/` | Bonn-derived UCI *Epileptic Seizure Recognition* CSV (downloaded automatically from the creators' repository and SHA-256 verified if absent) |
| `results/` | All CSV outputs (hold-out metrics, CV fold scores, statistical tests, ablation, SHAP, provenance, leakage, edge profile). Test-set probability files (`results/preds/`) are not included to keep the archive small; `run_all.py` regenerates them |
| `figures/` | All figures (PNG, 300 dpi) |
| `analysis.ipynb` | Executed notebook walking through the main pipeline |
| `extended_analyses/` | Rolling-origin evaluation, pre-specified primary model, fingerprint baselines, change-point analysis, CHB-MIT search, windowed models, tuned deep models, computational footprint and interval sensitivity (see below) |

## Reproduce

```bash
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt            # torch CPU: pip install torch --index-url https://download.pytorch.org/whl/cpu
python run_all.py                          # all stages (about 1–1.5 h on 8 CPU cores)
python run_all.py provenance leakage       # or individual stages
jupyter nbconvert --to notebook --execute analysis.ipynb --inplace
```

Stages: `provenance leakage holdout holdout_extra cv stats ablation shap windowed edge figures`.
Environment used: Linux, Python 3.13.5, 8 virtual CPUs, 16 GB RAM, no GPU. Seeds are fixed (`SEED = 42`).
Set `BEED_N_JOBS` to change parallelism.

## Key design choices

* **Groups.** Class-0 rows are grouped by their Bonn source segment (found by exact matching); class-1–3 rows (continuous
  multichannel recordings) are grouped into contiguous 200-row blocks.
* **Protocols.** *random* = stratified row-level split (as in prior work); *blocked* = whole groups held out, final 20% of
  each seizure recording as test, 50-row purge between training and test rows of the same recording.
* **Nested tuning.** Inner three-fold CV follows the same protocol as the outer split.
* **Uncertainty.** Cluster bootstrap (Bonn segments / 50-row chunks) in addition to the naive row bootstrap.

## Licence

Code: [choose licence, e.g. MIT]. Data remain under their original licences.

## Extended analyses (`extended_analyses/`)

These scripts reuse the core package (`src/beed`), the same data file, seeds, grids and 50-row purge. Run them from the
archive root after `run_all.py` (the raw+engineered CV of the core pipeline in `results/cv_fold_scores.csv` is reused):

```bash
cd extended_analyses/scripts
python r1_classical.py            # nested blocked/random 5x2 CV of all configurations, rolling origin, final-20% hold-out,
                                  # fingerprint and normalisation baselines (writes R1_* fold scores and results/preds/)
python r7_deep.py                 # deep models: 12-point grid tuned by an inner purged blocked hold-out (R7_*; slow on CPU)
python r6_windowed.py             # windowed multichannel LR vs paired single-row SVM-RBF on identical rows/splits (R6_*)
python r2_changepoints.py         # step, PELT/kernel change-point and boundary tests on classes 1-3 (R2_*)
python r2_boundary_enrichment.py  # hypergeometric enrichment of discontinuities at 100/200-row boundaries
python r5_positive_control.py     # CHB-MIT search: positive control (BEED rows injected with gain/offset/permutation)
python r5_chbmit_scan.py          # CHB-MIT v1.0.0 scan (streams EDF files from PhysioNet; hours, network access needed)
python r8_footprint.py            # latency and serialised size (native and ONNX) on one CPU thread (R8_*)
python summarise.py               # collects everything into the summary tables (R1_table4_extended_cv.csv,
                                  # R1_primary_model_headline.csv, R4_*, R7_deep_tuned_vs_default.csv, R9_*)
python figures_final.py           # publication figures in ../figures (figures.py: additional diagnostic figures)
python figure_confusion.py        # confusion matrices of the primary model (needs results/preds/)
```

`common.py` caches the loaded data and feature sets in `results/_ctx_cache.pkl` on first use (not included; rebuilt
automatically). Run logs, per-model probability files and lock files are not included. Extra requirements beyond
`requirements.txt`: `ruptures`, `onnx`, `onnxruntime`, `skl2onnx` and `onnxmltools` (the EDF reader for the CHB-MIT scan is included as `edf.py`).

Column naming in the result files: `original_default_*` and the model label `(original default, Table 5)` denote
models trained with the fixed default hyper-parameters of the core pipeline (no tuning); `original_headline_test_selected`
is the best classical score on the final-20% hold-out (SVM-RBF on raw values), i.e. a configuration selected on the
test block; source tags `original study` mark rows reused from the core pipeline. Rows with feature sets `recstd_raw`
and `rownorm_raw` (family `artefact` in the summaries) are invalid runs without de-quantisation, kept only to document
the integer-lattice artefact; they are not reported.
