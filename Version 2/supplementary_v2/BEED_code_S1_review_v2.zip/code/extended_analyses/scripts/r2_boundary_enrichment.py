"""R2 add-on: are discontinuities (low across-step spatial correlation and/or large steps) enriched at
multiples of 100 rows?  Exact hypergeometric test + list of every discontinuity."""
import numpy as np, pandas as pd
from scipy.stats import hypergeom
from common import Ctx, RES
ctx = Ctx(); X, y = ctx.X, ctx.y
rows, disc = [], []
for c in [1, 2, 3]:
    Xc = X[y == c]; n = len(Xc)
    step = np.linalg.norm(np.diff(Xc, axis=0), axis=1); med = np.median(step)
    rc = np.array([np.corrcoef(Xc[t], Xc[t + 1])[0, 1] for t in range(n - 1)])
    on100 = (np.arange(n - 1) + 1) % 100 == 0
    for name, flag in [("rowcorr<0.30", rc < 0.30), ("rowcorr<0.30 & step>4x median", (rc < 0.30) & (step > 4 * med)),
                       ("step>8x median", step > 8 * med)]:
        K = int(flag.sum()); k = int((flag & on100).sum()); N = n - 1; m = int(on100.sum())
        p = hypergeom.sf(k - 1, N, K, m) if K else 1.0
        rows.append({"class": c, "criterion": name, "n_steps": N, "n_flagged": K, "n_100row_boundaries": m,
                     "flagged_on_boundary": k, "expected_on_boundary": K * m / N, "hypergeom_p_enrichment": p,
                     "flagged_boundary_positions": [int(t + 1) for t in np.where(flag & on100)[0]]})
    for t in np.where((rc < 0.30) & (step > 4 * med))[0]:
        disc.append({"class": c, "boundary_before_pos": int(t + 1), "rowcorr": rc[t], "x_median_step": step[t] / med,
                     "on_100_boundary": bool(on100[t]), "on_200_boundary": (t + 1) % 200 == 0})
pd.DataFrame(rows).to_csv(RES / "R2_boundary_enrichment.csv", index=False)
pd.DataFrame(disc).to_csv(RES / "R2_discontinuities.csv", index=False)
pd.set_option("display.width", 250); print(pd.DataFrame(rows).to_string()); print(pd.DataFrame(disc).round(3).to_string())
