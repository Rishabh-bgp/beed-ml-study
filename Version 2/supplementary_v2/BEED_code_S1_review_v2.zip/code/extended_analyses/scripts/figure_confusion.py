"""Confusion matrices of the pre-specified primary model (LightGBM, raw values) on the hold-out sets (needs results/preds/, written by r1_classical.py)."""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from sklearn.metrics import confusion_matrix, f1_score
sns.set_theme(style="whitegrid", context="paper", font_scale=1.25)
from pathlib import Path
_EA = Path(__file__).resolve().parents[1]
P = str(_EA / "results" / "preds" / "holdout_{t}_{p}_raw_LightGBM_f0.npz")
NAMES = {"4class": ["H", "GS", "FS", "SE"], "3class": ["GS", "FS", "SE"]}
fig, axes = plt.subplots(1, 4, figsize=(17, 4.2)); k = 0
for t in ["4class", "3class"]:
    for p in ["random", "blocked"]:
        z = np.load(P.format(t=t, p=p)); y = z["y"].astype(int); yp = z["proba"].argmax(1)
        assert set(np.unique(y)) == set(range(len(NAMES[t])))
        cm = confusion_matrix(y, yp, labels=range(len(NAMES[t]))); cmn = cm / cm.sum(1, keepdims=True)
        ann = np.array([[f"{cm[i, j]}\n({cmn[i, j]:.2f})" for j in range(cm.shape[1])] for i in range(cm.shape[0])])
        ax = axes[k]; k += 1
        sns.heatmap(cmn, annot=ann, fmt="", cmap="Greys", vmin=0, vmax=1, cbar=False, ax=ax,
                    xticklabels=NAMES[t], yticklabels=NAMES[t], annot_kws={"size": 9})
        ax.set_xlabel("Predicted"); ax.set_ylabel("True")
        lab = {"4class": "four-class", "3class": "three-class"}[t]
        ax.set_title(f"{lab}, {p} hold-out\nLightGBM (raw); macro-F1 {f1_score(y, yp, average='macro'):.3f}", fontsize=10)
        print(t, p, round(f1_score(y, yp, average='macro'), 4), np.round(f1_score(y, yp, average=None), 4))
fig.tight_layout(); fig.savefig(_EA / "figures" / "fig_confusion_primary.png", dpi=300, bbox_inches="tight")
