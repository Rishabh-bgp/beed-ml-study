"""R6: windowed (temporal-context) analysis made comparable with the single-row models (3-class task).
* Same final-20% hold-out (rows pos>=1600 of each seizure class) and same 5x2 purged blocked CV (200-row blocks,
  50-row purge) as the single-row models.  Windows are non-overlapping, aligned at multiples of W within a class.
* Windowed model: StandardScaler + LogisticRegression on per-channel Welch band powers + line length (as in the
  core-pipeline stage_windowed); nested tuning of C in {0.01,0.1,1,10} and window length W in {32,64} rows by an inner
  3-fold purged blocked CV on the training windows.
* Single-row comparator: SVM-RBF on raw values (the best classical hold-out model), nested-tuned with the core-pipeline grid
  by inner purged blocked CV, trained on exactly the rows covered by the training windows and evaluated on exactly
  the rows covered by the test windows; window-level prediction = argmax of the mean row probability.
* CIs: stratified bootstrap over test windows (window = cluster), 2000 resamples; paired bootstrap for differences.
"""
import warnings; warnings.filterwarnings("ignore")
import json, numpy as np, pandas as pd
from scipy.signal import welch
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import f1_score
from joblib import Parallel, delayed
from common import *

ctx = Ctx(); X, y, pos = ctx.X, ctx.y, ctx.pos
GAP, BLOCK, FS = C.GAP, C.BLOCK, C.FS_BEED
BANDS = {"delta": (0.5, 4), "theta": (4, 8), "alpha": (8, 13), "beta": (13, 30), "gamma": (30, 70)}
CIDX = {c: np.where(y == c)[0] for c in (1, 2, 3)}
WLIST, CLIST = [32, 64], [0.01, 0.1, 1, 10]


def windows(W):
    U = []
    for c in (1, 2, 3):
        for s in range(0, 2000 - W + 1, W):
            U.append((c, s))
    U = pd.DataFrame(U, columns=["c", "s"]); U["W"] = W; U["e"] = U.s + W - 1; U["blk"] = U.s // BLOCK
    return U


def featurise(U):
    out = []
    for c, s, W in zip(U.c, U.s, U.W):
        w = X[CIDX[c][s:s + W]]; f, P = welch(w, fs=FS, nperseg=W, axis=0); row = []
        for ch in range(16):
            for lo, hi in BANDS.values():
                row.append(np.log(P[(f >= lo) & (f < hi), ch].sum() + 1e-6))
            row.append(np.log(np.abs(np.diff(w[:, ch])).sum() + 1e-6))
        out.append(row)
    return np.array(out)


def far(U, i_tr, i_te):
    """keep training windows whose rows are > GAP rows from every test window row of the same class"""
    keep = []
    for i in i_tr:
        t = U.iloc[i_te]; t = t[t.c == U.c.iat[i]]
        d = np.minimum(np.abs(t.s.values - U.e.iat[i]), np.abs(U.s.iat[i] - t.e.values)) if len(t) else np.array([1e9])
        ovl = (U.s.iat[i] <= t.e.values) & (t.s.values <= U.e.iat[i]) if len(t) else np.array([False])
        if (d > GAP).all() and not ovl.any(): keep.append(i)
    return np.array(keep, int)


def blocked_folds(U, units, n_splits, n_rep, seed=C.SEED):
    sp = []
    for r in range(n_rep):
        rng = np.random.RandomState(seed + r); fold = np.full(len(U), -1)
        for c in (1, 2, 3):
            m = units[U.c.values[units] == c]; b = np.unique(U.blk.values[m]); b = b[rng.permutation(len(b))]
            fk = {bb: k % n_splits for k, bb in enumerate(b)}
            for i in m: fold[i] = fk[U.blk.iat[i]]
        for k in range(n_splits):
            te = units[fold[units] == k]; tr = far(U, units[fold[units] != k], te); sp.append((tr, te))
    return sp


def window_rows(U, ii):
    return np.concatenate([CIDX[U.c.iat[i]][U.s.iat[i]:U.s.iat[i] + U.W.iat[i]] for i in ii])


def boot(yw, pw, n=2000, seed=42, other=None, clusters=None):
    """stratified bootstrap over windows (clusters=None) or over clusters of windows (e.g. 50-row chunks)"""
    rng = np.random.RandomState(seed); res = []; labs = np.unique(yw)
    cl = np.arange(len(yw)) if clusters is None else np.asarray(clusters)
    by = {c: [np.where((cl == u) & (yw == c))[0] for u in np.unique(cl[yw == c])] for c in labs}
    for _ in range(n):
        ii = np.concatenate([np.concatenate([by[c][j] for j in rng.randint(0, len(by[c]), len(by[c]))]) for c in labs])
        a = f1_score(yw[ii], pw[ii], average="macro", labels=labs)
        res.append(a - f1_score(yw[ii], other[ii], average="macro", labels=labs) if other is not None else a)
    return np.percentile(res, [2.5, 97.5])


def evaluate_split(dev_mask_fn, test_fn, label, fold, inner_seed=0):
    """dev_mask_fn(U)-> indices of candidate training windows; test_fn(U)-> test window indices."""
    best = (-1, None, None)
    data_by_W = {}
    for W in WLIST:
        U = windows(W); Fw = featurise(U); yw = U.c.values - 1
        te = test_fn(U); tr = far(U, dev_mask_fn(U), te)
        data_by_W[W] = (U, Fw, yw, tr, te)
        inner = blocked_folds(U, tr, 3, 1, seed=C.SEED + inner_seed)
        loc = {g: i for i, g in enumerate(tr)}
        inner_l = [(np.array([loc[i] for i in a]), np.array([loc[i] for i in b])) for a, b in inner]
        gs = GridSearchCV(make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000)),
                          {"logisticregression__C": CLIST}, cv=inner_l, scoring="f1_macro").fit(Fw[tr], yw[tr])
        if gs.best_score_ > best[0]: best = (gs.best_score_, W, gs.best_params_["logisticregression__C"])
    _, W, Cb = best
    U, Fw, yw, tr, te = data_by_W[W]
    m = make_pipeline(StandardScaler(), LogisticRegression(C=Cb, max_iter=5000)).fit(Fw[tr], yw[tr])
    pw = m.predict(Fw[te])
    # single-row SVM-RBF on exactly the same rows
    rtr, rte = window_rows(U, tr), window_rows(U, te)
    yt = y - 1
    inner_r = data.inner_cv("blocked", y, pos, ctx.groups, rtr, 3)
    est, grid = models.get_models()["SVM-RBF"]
    gs = GridSearchCV(clone(est).set_params(svc__probability=False), grid, cv=inner_r, scoring="f1_macro", refit=False).fit(X[rtr], yt[rtr])
    svm = clone(est).set_params(**gs.best_params_).fit(X[rtr], yt[rtr])
    pr = svm.predict_proba(X[rte])
    # window-level aggregation of the single-row model
    pos_in = np.cumsum([0] + [U.W.iat[i] for i in te])
    pagg = np.array([pr[pos_in[k]:pos_in[k + 1]].mean(0).argmax() for k in range(len(te))])
    row = {"split": label, "fold": fold, "chosen_W": W, "chosen_C": Cb, "n_train_windows": len(tr), "n_test_windows": len(te),
           "n_test_rows": len(rte), "windowed_LR_f1": f1_score(yw[te], pw, average="macro"),
           "singlerow_SVM_rowlevel_f1": f1_score(yt[rte], pr.argmax(1), average="macro"),
           "singlerow_SVM_windowvote_f1": f1_score(yw[te], pagg, average="macro"),
           "svm_params": json.dumps(gs.best_params_)}
    return row, (yw[te], pw, pagg, yt[rte], pr.argmax(1), U.iloc[te])


if __name__ == "__main__":
    rows, outs = [], {}
    # --- hold-out: test = windows fully inside pos>=1600; dev = all other windows (purged by `far`)
    test_fn = lambda U: np.where(U.s.values >= 1600)[0]
    dev_fn = lambda U: np.where(U.e.values < 1600)[0]
    r, o = evaluate_split(dev_fn, test_fn, "holdout_final20", 0); rows.append(r); outs["holdout"] = o
    yw, pw, pagg, yr, prr, Ute = o
    ci_w = boot(yw, pw); ci_a = boot(yw, pagg); ci_d = boot(yw, pw, other=pagg)
    wcl = np.array([f"{c}_{s // 100}" for c, s in zip(Ute.c, Ute.s)])
    ci_w100 = boot(yw, pw, clusters=wcl); ci_d100 = boot(yw, pw, other=pagg, clusters=wcl)
    import pickle; pickle.dump(o, open(RES / "R6_holdout_preds.pkl", "wb"))
    # row-level CI for single-row model (50-row cluster bootstrap within class)
    cl = np.concatenate([[f"{c}_{(s + j) // 50}" for j in range(W)] for c, s, W in zip(Ute.c, Ute.s, Ute.W)])
    ci_r = E.bootstrap_ci(yr, prr, clusters=np.array(cl, dtype=object))
    rows[-1].update({"windowed_LR_ci": json.dumps(np.round(ci_w, 3).tolist()), "singlerow_windowvote_ci": json.dumps(np.round(ci_a, 3).tolist()),
                     "diff_windowed_minus_vote_ci": json.dumps(np.round(ci_d, 3).tolist()),
                     "windowed_LR_ci_100rowclusters": json.dumps(np.round(ci_w100, 3).tolist()),
                     "diff_ci_100rowclusters": json.dumps(np.round(ci_d100, 3).tolist()),
                     "singlerow_rowlevel_cluster_ci": json.dumps([round(ci_r["f1_lo"], 3), round(ci_r["f1_hi"], 3)])})
    print(rows[-1], flush=True)
    # --- 5x2 purged blocked CV on the development region (pos < 1550 after purge)
    def cv_job(k):
        def mk_splits(U):
            dev = np.where(U.e.values < 1600 - GAP)[0]
            return blocked_folds(U, dev, 5, 2)
        # fold structure must be identical across W at the row level -> define by 200-row blocks (same seeds)
        def te_fn(U, k=k): return mk_splits(U)[k][1]
        def dev_fn2(U, k=k):
            dev = np.where(U.e.values < 1600 - GAP)[0]; return np.setdiff1d(dev, mk_splits(U)[k][1])
        return evaluate_split(dev_fn2, te_fn, "cv5x2_blocked", k, inner_seed=k + 1)
    res = Parallel(n_jobs=int(os.environ.get("R6_JOBS", 2)))(delayed(cv_job)(k) for k in range(10))
    for r, o in res: rows.append(r)
    df = pd.DataFrame(rows); df.to_csv(RES / "R6_windowed_vs_singlerow.csv", index=False)
    cv = df[df.split == "cv5x2_blocked"]
    summ = {k: f"{cv[k].mean():.3f} ± {cv[k].std(ddof=1):.3f}" for k in ["windowed_LR_f1", "singlerow_SVM_rowlevel_f1", "singlerow_SVM_windowvote_f1"]}
    print("CV:", summ, "\nchosen W:", cv.chosen_W.value_counts().to_dict(), "chosen C:", cv.chosen_C.value_counts().to_dict())
    json.dump(summ, open(RES / "R6_cv_summary.json", "w"), indent=1)
