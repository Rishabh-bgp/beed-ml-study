"""R5 positive control: inject a gain/offset-transformed, channel-permuted copy of BEED rows into a real CHB-MIT
file and check that the scan statistic recovers it (and that the clean file does not)."""
import numpy as np, pandas as pd, urllib.request, os
from scipy import fft as sfft
import r5_chbmit_scan as R, edf
path = "/tmp/chb01_03_pc.edf"
if not os.path.exists(path): urllib.request.urlretrieve(R.BASE + "chb01/chb01_03.edf", path)
e = edf.read_edf(path); sig = np.array([s.astype(np.float64) for s in e["sig"]])   # (23, N)
rng = np.random.RandomState(0); out = []
for c, at in [(1, 200000), (2, 400000), (3, 600000)]:
    S = sig.copy()
    rows = R.X[R.y == c][800:1300]                       # 500 BEED rows covering the query window (rows 900-1099)
    perm = rng.permutation(23)[:16]
    for j in range(16):
        S[perm[j], at:at + len(rows)] = np.round(rows[:, j] * 7 + 13)   # integer gain 7, offset 13
    D = np.diff(S, axis=1).astype(np.float32); N = D.shape[1]; nfft = sfft.next_fast_len(N + R.LQ)
    Sf = sfft.rfft(D, nfft, axis=1); nlag = N - R.LQ + 1
    sd = np.array([R.sliding_sd(s, R.LQ) for s in D]); sd[sd < 0.5] = np.inf
    for qn, Q in R.QP.items():
        acc = np.zeros(nlag, np.float32)
        for j in range(16):
            qf = np.conj(sfft.rfft(Q[:, j].astype(np.float32), nfft))
            acc += (sfft.irfft(Sf * qf[None, :], nfft, axis=1)[:, :nlag] / (R.LQ * sd)).max(0)
        acc /= 16; lag = int(acc.argmax())
        out.append({"injected_class": c, "inject_at": at, "expected_lag": at + 100, "query": qn, "peak": float(acc[lag]), "lag": lag})
        print(out[-1], flush=True)
pd.DataFrame(out).to_csv(R.OUT.replace("r5_chbmit_scan.csv", "r5_positive_control.csv"), index=False)
