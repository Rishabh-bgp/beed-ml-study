"""Collect all extended-analysis results into summary tables (results/)."""
import warnings; warnings.filterwarnings("ignore")
import glob, json
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import *
ctx = Ctx()
ORIG = REV.parent / "results"
K = {"4class": 4, "3class": 3}
PREDS = RES / "preds"

# ------------------------------------------------------------------ load
def fam(f, m):
    if f.startswith("fp_"): return "fingerprint"
    if f in ("recstd_raw", "rownorm_raw"): return "artefact"   # integer-lattice label leak; replaced by *_dq (de-quantised)
    if f in ("recstd_dq", "rownorm_dq"): return "normalised"
    if m in ("MLP", "1D-CNN", "BiLSTM", "Transformer"): return "deep"
    return "main"

oc = pd.read_csv(ORIG / "cv_fold_scores.csv")
oc_cls = oc[~oc.model.isin(["MLP", "1D-CNN"])].assign(features="raw+eng", scheme="cv", source="original study (re-used)")
oc_deep = oc[oc.model.isin(["MLP", "1D-CNN"])].assign(features="raw", scheme="cv", source="original study, untuned defaults")
r1cv = pd.read_csv(RES / "R1_cv_fold_scores.csv").assign(source="revision_v2") if (RES / "R1_cv_fold_scores.csv").exists() else pd.DataFrame()
r7 = pd.concat([pd.read_csv(f) for f in glob.glob(str(RES / "R7_deep_fold_scores_part*.csv"))]) if glob.glob(str(RES / "R7_deep_fold_scores_part*.csv")) else pd.DataFrame()
if len(r7): r7 = r7.drop_duplicates(["task", "scheme", "protocol", "model", "fold"]).assign(source=lambda d: np.where(d.tuned, "revision_v2 (inner-blocked grid)", "revision_v2 (fixed defaults)"))
def rd(*names):
    fs = [RES / n for n in names if (RES / n).exists()]
    return pd.concat([pd.read_csv(f) for f in fs], ignore_index=True) if fs else pd.DataFrame()
roll = rd("R1_rolling_fold_scores.csv", "R1_rolling_fold_scores_dq.csv")
hold = rd("R1_holdout_fold_scores.csv", "R1_holdout_fold_scores_dq.csv")

cv = pd.concat([oc_cls, r1cv, r7[r7.scheme == "cv"] if len(r7) else None], ignore_index=True)
cv["family"] = [fam(f, m) for f, m in zip(cv.features, cv.model)]
rollall = pd.concat([roll, r7[r7.scheme == "rolling"] if len(r7) else None], ignore_index=True)
rollall["family"] = [fam(f, m) for f, m in zip(rollall.features, rollall.model)]
holdall = pd.concat([hold, r7[r7.scheme == "holdout"] if len(r7) else None], ignore_index=True)
holdall["family"] = [fam(f, m) for f, m in zip(holdall.features, holdall.model)]

def agg(d, keys):
    return d.groupby(keys).agg(mean=("macro_f1", "mean"), sd=("macro_f1", "std"), n_folds=("macro_f1", "size"),
                               acc_mean=("accuracy", "mean"), kappa_mean=("kappa", "mean")).reset_index()

t4 = agg(cv, ["task", "protocol", "family", "features", "model"])
src = cv.groupby(["task", "protocol", "features", "model"]).source.first().reset_index()
t4 = t4.merge(src, on=["task", "protocol", "features", "model"])
t4.sort_values(["task", "protocol", "family", "mean"], ascending=[True, True, True, False]).to_csv(RES / "R1_table4_extended_cv.csv", index=False)

ra = agg(rollall, ["task", "family", "features", "model"])
tq = stats.t.ppf(0.975, 4)
ra["t95_lo"] = ra["mean"] - tq * ra.sd / np.sqrt(ra.n_folds); ra["t95_hi"] = ra["mean"] + tq * ra.sd / np.sqrt(ra.n_folds)
pf = rollall.pivot_table(index=["task", "features", "model"], columns="fold", values="macro_f1").reset_index()
pf.columns = [f"fold{c}_f1" if isinstance(c, (int, np.integer)) else c for c in pf.columns]
ra = ra.merge(pf, on=["task", "features", "model"])
ra["min"] = ra[[c for c in ra.columns if c.startswith("fold")]].min(1); ra["max"] = ra[[c for c in ra.columns if c.startswith("fold")]].max(1)
ra.sort_values(["task", "family", "mean"], ascending=[True, True, False]).to_csv(RES / "R1_rolling_origin_summary.csv", index=False)

# ------------------------------------------------------------------ CIs on hold-out predictions (R9)
def pred_file(scheme, task, prot, fset, model, fold=0):
    p = PREDS / f"{scheme}_{task}_{prot}_{fset}_{model}_f{fold}.npz"
    return np.load(p) if p.exists() else None

def ci_set(task, fset, model, prot="blocked"):
    z = pred_file("holdout", task, prot, fset, model)
    if z is None: return None
    idx, yy, pr = z["idx"], z["y"], z["proba"]; pred = pr.argmax(1)
    out = {"task": task, "protocol": prot, "features": fset, "model": model, "macro_f1": E.metrics(yy, pred)["macro_f1"]}
    ci = E.bootstrap_ci(yy, pred); out.update(naive_lo=ci["f1_lo"], naive_hi=ci["f1_hi"])
    for s in (25, 50, 100):
        cl = ctx.clusters(s)[idx]; ci = E.bootstrap_ci(yy, pred, clusters=cl)
        out.update({f"cluster{s}_lo": ci["f1_lo"], f"cluster{s}_hi": ci["f1_hi"],
                    f"n_clusters_per_seizure_class_{s}": int(400 / s)})
    return out

# ------------------------------------------------------------------ primary model (selected on blocked dev CV only)
prim = []
for task in ["4class", "3class"]:
    c = t4[(t4.task == task) & (t4.protocol == "blocked") & t4.family.isin(["main", "deep"]) & (t4.n_folds == 10)].sort_values("mean", ascending=False)
    top = c.iloc[0]
    r = {"task": task, "selection_rule": "highest mean macro-F1 in the nested purged blocked 5x2 CV on the development set (test block never used)",
         "primary_features": top.features, "primary_model": top.model, "cv_blocked_mean": top["mean"], "cv_blocked_sd": top.sd,
         "runner_up": f"{c.iloc[1].model} ({c.iloc[1].features}) {c.iloc[1]['mean']:.3f}"}
    rr = ra[(ra.task == task) & (ra.features == top.features) & (ra.model == top.model)]
    if len(rr): r.update(rolling_mean=rr["mean"].iloc[0], rolling_sd=rr.sd.iloc[0], rolling_t95_lo=rr.t95_lo.iloc[0], rolling_t95_hi=rr.t95_hi.iloc[0],
                         rolling_min=rr["min"].iloc[0], rolling_max=rr["max"].iloc[0])
    h = ci_set(task, top.features, top.model)
    if h: r.update(holdout_f1=h["macro_f1"], holdout_cluster50_lo=h["cluster50_lo"], holdout_cluster50_hi=h["cluster50_hi"])
    # fully nested selection inside rolling-origin (classical candidates; selection by inner-CV score per fold)
    rm = roll[np.array([fam(f, m) == "main" for f, m in zip(roll.features, roll.model)]) & (roll.task == task).values]
    sel = rm.loc[rm.groupby("fold").inner_cv_f1.idxmax()]
    r.update(nested_selection_rolling_mean=sel.macro_f1.mean(), nested_selection_rolling_sd=sel.macro_f1.std(),
             nested_selection_choices=json.dumps([f"f{k}:{m}({f})" for k, m, f in zip(sel.fold, sel.model, sel.features)]),
             nested_selection_per_fold=json.dumps([round(v, 3) for v in sel.macro_f1]))
    old = {"4class": 0.8415, "3class": 0.7756}[task]
    r["original_headline_test_selected"] = old
    prim.append(r)
prim = pd.DataFrame(prim); prim.to_csv(RES / "R1_primary_model_headline.csv", index=False)

# ------------------------------------------------------------------ R9: CI sensitivity
cis = []
for task in ["4class", "3class"]:
    p = prim[prim.task == task].iloc[0]
    for fset, model, role in [(p.primary_features, p.primary_model, "primary (CV-selected)"), ("raw", "SVM-RBF", "original headline (test-selected)"),
                              ("raw+eng", "LightGBM", "original CV winner"), ("fp_absraw", "LR", "amplitude fingerprint baseline")]:
        o = ci_set(task, fset, model)
        if o:
            o["role"] = role
            rr = ra[(ra.task == task) & (ra.features == fset) & (ra.model == model)]
            if len(rr): o.update(rolling_mean=rr["mean"].iloc[0], rolling_sd=rr.sd.iloc[0], rolling_t95_lo=rr.t95_lo.iloc[0], rolling_t95_hi=rr.t95_hi.iloc[0], rolling_min=rr["min"].iloc[0], rolling_max=rr["max"].iloc[0])
            cis.append(o)
cis = pd.DataFrame(cis).drop_duplicates(["task", "features", "model"]); cis.to_csv(RES / "R9_ci_sensitivity.csv", index=False)

# ------------------------------------------------------------------ R9: Holm across all settings (+ within-setting for comparison)
tt = []
for (task, prot), d in cv[cv.family.isin(["main", "deep"])].groupby(["task", "protocol"]):
    d = d.assign(cfg=d.model + " (" + d.features + ")")
    tab = d.pivot_table(index="fold", columns="cfg", values="macro_f1")
    tab = tab.dropna(axis=1)
    best = tab.mean().idxmax(); ntr, nte = d.n_train.mean(), d.n_test.mean()
    for m in tab.columns:
        if m == best: continue
        t, pv = E.corrected_ttest(tab[best], tab[m], ntr, nte)
        tt.append({"task": task, "protocol": prot, "best": best, "other": m, "best_mean": tab[best].mean(), "other_mean": tab[m].mean(), "t": t, "p": pv})
tt = pd.DataFrame(tt)
tt["p_holm_within_setting"] = tt.groupby(["task", "protocol"]).p.transform(lambda s: E.holm(s.values))
tt["p_holm_all_settings"] = E.holm(tt.p.values)
tt.to_csv(RES / "R9_holm_all_settings.csv", index=False)

# pre-specified comparisons: primary vs amplitude fingerprint (LR on |x|), blocked CV and rolling origin
pre = []
for task in ["4class", "3class"]:
    p = prim[prim.task == task].iloc[0]
    for scheme, d in [("cv_blocked", cv[(cv.task == task) & (cv.protocol == "blocked")]), ("rolling_origin", rollall[rollall.task == task])]:
        a = d[(d.features == p.primary_features) & (d.model == p.primary_model)].set_index("fold").macro_f1
        b = d[(d.features == "fp_absraw") & (d.model == "LR")].set_index("fold").macro_f1
        if len(a) and len(b):
            a, b = a.align(b, join="inner")
            ntr, nte = d.n_train.mean(), d.n_test.mean()
            t, pv = E.corrected_ttest(a, b, ntr, nte)
            pre.append({"task": task, "scheme": scheme, "comparison": f"{p.primary_model} ({p.primary_features}) vs LR(|x|) fingerprint",
                        "mean_primary": a.mean(), "mean_fingerprint": b.mean(), "mean_diff": (a - b).mean(), "n_folds": len(a), "t_corrected": t, "p": pv})
pre = pd.DataFrame(pre)
if len(pre): pre["p_holm"] = E.holm(pre.p.values)
pre.to_csv(RES / "R9_prespecified_tests.csv", index=False)

# ------------------------------------------------------------------ R4 table
r4 = []
for task in ["4class", "3class"]:
    p = prim[prim.task == task].iloc[0]
    cands = [(p.primary_features, p.primary_model), ("raw", "SVM-RBF"), ("raw+eng", "LightGBM")] + \
            [(f, m) for f in ["fp_absraw", "fp_rowsd", "fp_rowmean", "fp_rowstats"] for m in ["LR", "LightGBM"]] + \
            [(f, m) for f in ["recstd_dq", "rownorm_dq", "recstd_raw"] for m in ["LR", "kNN", "SVM-RBF", "LightGBM"]]
    seen = set()
    for f, m in cands:
        if (f, m) in seen: continue
        seen.add((f, m)); r = {"task": task, "features": f, "model": m, "family": fam(f, m)}
        for prot in ["random", "blocked"]:
            h = holdall[(holdall.task == task) & (holdall.protocol == prot) & (holdall.features == f) & (holdall.model == m)]
            r[f"holdout_{prot}"] = h.macro_f1.iloc[0] if len(h) else np.nan
            c = t4[(t4.task == task) & (t4.protocol == prot) & (t4.features == f) & (t4.model == m)]
            r[f"cv_{prot}"] = f"{c['mean'].iloc[0]:.3f} ± {c.sd.iloc[0]:.3f}" if len(c) else ""
            r[f"cv_{prot}_mean"] = c["mean"].iloc[0] if len(c) else np.nan
        rr = ra[(ra.task == task) & (ra.features == f) & (ra.model == m)]
        r["rolling"] = f"{rr['mean'].iloc[0]:.3f} ± {rr.sd.iloc[0]:.3f}" if len(rr) else ""
        r["rolling_mean"] = rr["mean"].iloc[0] if len(rr) else np.nan
        r4.append(r)
r4 = pd.DataFrame(r4)
for task in ["4class", "3class"]:
    m = r4.task == task; ch = 1 / K[task]
    ref = r4[m & (r4.features == prim[prim.task == task].primary_features.iloc[0]) & (r4.model == prim[prim.task == task].primary_model.iloc[0])]
    for col in ["rolling_mean", "cv_blocked_mean", "holdout_blocked"]:
        r4.loc[m, f"share_of_primary_above_chance_{col}"] = (r4.loc[m, col] - ch) / (ref[col].iloc[0] - ch)
r4.to_csv(RES / "R4_fingerprint_baselines.csv", index=False)

# ------------------------------------------------------------------ R7 summary
if len(r7):
    oh = pd.read_csv(ORIG / "holdout_metrics.csv")
    r7s = []
    for (task, arch), d in r7[r7.protocol == "blocked"].groupby(["task", "model"]):
        r = {"task": task, "model": arch}
        for sch in ["cv", "rolling", "holdout"]:
            dd = d[d.scheme == sch]
            r[f"tuned_{sch}_mean"] = dd.macro_f1.mean() if len(dd) else np.nan; r[f"tuned_{sch}_sd"] = dd.macro_f1.std() if len(dd) > 1 else np.nan
            r[f"{sch}_n_folds"] = len(dd)
        r["chosen_configs"] = json.dumps(d.chosen.value_counts().to_dict())
        o = oh[(oh.task == task) & (oh.protocol == "blocked") & (oh.model == arch) & (oh.features == "raw")]
        r["original_default_holdout"] = o.macro_f1.iloc[0] if len(o) else np.nan
        oc2 = oc_deep[(oc_deep.task == task) & (oc_deep.protocol == "blocked") & (oc_deep.model == arch)]
        r["original_default_cv"] = f"{oc2.macro_f1.mean():.3f} ± {oc2.macro_f1.std():.3f}" if len(oc2) else "not run in original"
        r["mean_epochs"] = d.epochs.mean(); r["n_params_range"] = f"{d.n_params.min()}-{d.n_params.max()}"
        r7s.append(r)
    pd.DataFrame(r7s).to_csv(RES / "R7_deep_tuned_vs_default.csv", index=False)
print("tables written")
