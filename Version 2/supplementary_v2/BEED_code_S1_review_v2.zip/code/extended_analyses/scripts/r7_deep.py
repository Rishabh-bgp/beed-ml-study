"""R7 (+R1): deep models with an inner-blocked hyper-parameter grid, evaluated in the 5x2 purged blocked CV,
the 5-fold rolling-origin evaluation and the final-20% hold-out.  Random-protocol CV uses fixed defaults.
Tuning (per outer fold): inner hold-out = 20% of the outer-training groups (200-row blocks / Bonn segments,
class-stratified), purged by 50 rows; each grid point is trained on the remaining inner-training rows
(early stopping on a further 15% group split) and scored by macro-F1 on the inner hold-out; the best grid
point is refitted on the whole outer-training set (again with a 15% group split for early stopping).
Usage: python r7_deep.py <n_jobs>"""
import os, sys, json, time
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from common import *
import deep2

ctx = Ctx(); X, y, pos, G = ctx.X, ctx.y, ctx.pos, ctx.groups
PRED = RES / "preds"; PRED.mkdir(exist_ok=True)


def group_holdout(tr, frac, seed, prot):
    """positions (within tr) of a validation subset, plus positions to drop (purged)."""
    rng = np.random.RandomState(seed)
    if prot == "random":
        v = rng.choice(len(tr), int(frac * len(tr)), replace=False)
        return np.sort(v), np.setdiff1d(np.arange(len(tr)), v)
    vmask = np.zeros(len(tr), bool)
    for c in np.unique(y[tr]):
        g = np.unique(G[tr][y[tr] == c]); k = max(1, int(round(frac * len(g))))
        vg = rng.choice(g, k, replace=False); vmask |= np.isin(G[tr], vg) & (y[tr] == c)
    v = tr[vmask]
    rest = data.purge(tr[~vmask], v, y, pos)
    return np.where(vmask)[0], np.where(np.isin(tr, rest))[0]


def fit_cfg(arch, tr, yt, n_cls, cfg, prot, seed=42):
    vpos, trpos = group_holdout(tr, 0.15, seed, prot)
    use = np.sort(np.r_[vpos, trpos]); loc = np.full(len(tr), -1); loc[use] = np.arange(len(use))
    return deep2.Deep(arch, n_cls, **cfg).fit(X[tr[use]], yt[tr[use]], loc[vpos])


LOCK = RES / "_r7_locks"; LOCK.mkdir(exist_ok=True)


def run(task, scheme, prot, fold, tr, te, arch, yt, tune):
    """dynamic work queue: a job is skipped if another process already claimed it (atomic lock file)"""
    key = f"{task}_{scheme}_{prot}_{arch}_f{fold}"
    try:
        os.close(os.open(LOCK / key, os.O_CREAT | os.O_EXCL | os.O_WRONLY))
    except FileExistsError:
        return None
    t0 = time.time(); n_cls = int(yt[te].max() + 1) if task == "3class" else 4
    n_cls = 3 if task == "3class" else 4
    inner = []
    if tune:
        ipos, itrpos = group_holdout(tr, 0.2, 7 + fold, prot)
        itr, iva = tr[itrpos], tr[ipos]
        for cfg in deep2.GRID:
            m = fit_cfg(arch, itr, yt, n_cls, cfg, prot)
            f1 = E.metrics(yt[iva], m.predict_proba(X[iva]).argmax(1))["macro_f1"]
            inner.append({**cfg, "inner_f1": f1, "epochs": m.epochs_})
        best = max(inner, key=lambda r: r["inner_f1"]); cfg = {k: best[k] for k in ("lr", "w", "p")}
    else:
        cfg = deep2.DEFAULT[arch]
    m = fit_cfg(arch, tr, yt, n_cls, cfg, prot)
    proba = m.predict_proba(X[te])
    mm = E.metrics(yt[te], proba.argmax(1), proba, np.arange(n_cls))
    if scheme != "cv":
        np.savez_compressed(PRED / f"{scheme}_{task}_{prot}_raw_{arch}_f{fold}.npz", idx=te, y=yt[te], proba=proba)
    return {"task": task, "scheme": scheme, "protocol": prot, "fold": fold, "features": "raw", "model": arch,
            "tuned": tune, "n_train": len(tr), "n_test": len(te), "chosen": json.dumps(cfg),
            "inner_f1": max([r["inner_f1"] for r in inner]) if inner else np.nan, "inner_grid": json.dumps(inner),
            "n_params": deep2.n_params(m.model), "epochs": m.epochs_, "fit_seconds": time.time() - t0, **mm}


def jobs():
    J = []
    for task in ["4class", "3class"]:
        idx, yt = ctx.task(task)
        dev, te = data.holdout("blocked", y, pos, G, idx)
        sets = [("holdout", [(dev, te)]), ("rolling", rolling_origin_splits(ctx, idx)),
                ("cv", data.splits("blocked", y, pos, G, dev))]
        for arch in ["Transformer", "1D-CNN", "BiLSTM", "MLP"]:
            for scheme, sp in sets:
                for k, (a, b) in enumerate(sp):
                    J.append((task, scheme, "blocked", k, a, b, arch, yt, True))
        devr, ter = data.holdout("random", y, pos, G, idx)
        for arch in ["Transformer", "1D-CNN", "BiLSTM", "MLP"]:
            for k, (a, b) in enumerate(data.splits("random", y, pos, G, devr)):
                J.append((task, "cv", "random", k, a, b, arch, yt, False))
    return J


if __name__ == "__main__":
    nj = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    J = jobs(); print(len(J), "outer jobs", flush=True)
    out = RES / f"R7_deep_fold_scores_part{os.getpid()}.csv"; rows = []; t0 = time.time()
    if len(sys.argv) > 2 and sys.argv[2] == "reverse": J = J[::-1]
    for i, r in enumerate(Parallel(n_jobs=nj, return_as="generator_unordered")(delayed(run)(*j) for j in J)):
        if r is None: continue
        rows.append(r); pd.DataFrame(rows).to_csv(out, index=False)
        print(f"{i+1}/{len(J)} {time.time()-t0:.0f}s {r['task']} {r['scheme']} {r['protocol']} {r['model']} f{r['fold']} f1={r['macro_f1']:.3f} cfg={r['chosen']} ({r['fit_seconds']:.0f}s)", flush=True)
