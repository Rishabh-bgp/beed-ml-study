"""Width/dropout-parametrised versions of the study's deep models (same topology as code/src/beed/deep.py)."""
import numpy as np, torch, torch.nn as nn
from sklearn.metrics import f1_score


class MLP(nn.Module):
    def __init__(self, n_cls=4, w=1.0, p=0.2):
        super().__init__(); h1, h2 = int(128 * w), int(64 * w)
        self.net = nn.Sequential(nn.Linear(16, h1), nn.BatchNorm1d(h1), nn.ReLU(), nn.Dropout(p),
                                 nn.Linear(h1, h2), nn.BatchNorm1d(h2), nn.ReLU(), nn.Dropout(p), nn.Linear(h2, n_cls))
    def forward(self, x): return self.net(x)


class CNN1D(nn.Module):
    def __init__(self, n_cls=4, w=1.0, p=0.2):
        super().__init__(); c = int(32 * w)
        self.f = nn.Sequential(nn.Conv1d(1, c, 3, padding=1), nn.BatchNorm1d(c), nn.ReLU(),
                               nn.Conv1d(c, 2 * c, 3, padding=1), nn.BatchNorm1d(2 * c), nn.ReLU(), nn.MaxPool1d(2),
                               nn.Conv1d(2 * c, 2 * c, 3, padding=1), nn.BatchNorm1d(2 * c), nn.ReLU())
        self.head = nn.Sequential(nn.Dropout(p), nn.Linear(4 * c, n_cls))
    def forward(self, x):
        h = self.f(x.unsqueeze(1)); return self.head(torch.cat([h.mean(-1), h.amax(-1)], 1))


class BiLSTM(nn.Module):
    def __init__(self, n_cls=4, w=1.0, p=0.2):
        super().__init__(); h = int(48 * w)
        self.lstm = nn.LSTM(1, h, batch_first=True, bidirectional=True)
        self.head = nn.Sequential(nn.Dropout(p), nn.Linear(4 * h, n_cls))
    def forward(self, x):
        o, _ = self.lstm(x.unsqueeze(-1)); return self.head(torch.cat([o.mean(1), o[:, -1]], 1))


class TinyTransformer(nn.Module):
    def __init__(self, n_cls=4, w=1.0, p=0.1, L=16):
        super().__init__(); d = int(32 * w)
        self.emb = nn.Linear(1, d); self.pos = nn.Parameter(torch.randn(1, L, d) * 0.02)
        layer = nn.TransformerEncoderLayer(d, 4, 2 * d, dropout=p, batch_first=True)
        self.enc = nn.TransformerEncoder(layer, 2, enable_nested_tensor=False); self.head = nn.Linear(d, n_cls)
    def forward(self, x): return self.head(self.enc(self.emb(x.unsqueeze(-1)) + self.pos).mean(1))


ARCH = {"MLP": MLP, "1D-CNN": CNN1D, "BiLSTM": BiLSTM, "Transformer": TinyTransformer}
DEFAULT = {"MLP": dict(lr=2e-3, w=1.0, p=0.2), "1D-CNN": dict(lr=2e-3, w=1.0, p=0.2),
           "BiLSTM": dict(lr=2e-3, w=1.0, p=0.2), "Transformer": dict(lr=2e-3, w=1.0, p=0.1)}
GRID = [dict(lr=lr, w=w, p=p) for lr in (1e-3, 3e-3) for w in (0.5, 1.0, 2.0) for p in (0.0, 0.2)]


def n_params(m): return sum(q.numel() for q in m.parameters() if q.requires_grad)


class Deep:
    def __init__(self, arch, n_cls, lr=2e-3, w=1.0, p=0.2, max_epochs=100, patience=15, bs=128, seed=42):
        self.arch, self.n_cls, self.lr, self.w, self.p = arch, n_cls, lr, w, p
        self.max_epochs, self.patience, self.bs, self.seed = max_epochs, patience, bs, seed

    def fit(self, X, y, val_idx):
        torch.set_num_threads(1); torch.manual_seed(self.seed); np.random.seed(self.seed)
        self.mu, self.sd = X.mean(0), X.std(0) + 1e-6
        Xs = ((X - self.mu) / self.sd).astype(np.float32)
        tr = np.setdiff1d(np.arange(len(y)), val_idx)
        Xt, yt = torch.tensor(Xs[tr]), torch.tensor(y[tr]); Xv, yv = torch.tensor(Xs[val_idx]), y[val_idx]
        self.model = ARCH[self.arch](n_cls=self.n_cls, w=self.w, p=self.p)
        opt = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, factor=0.5, patience=4)
        lossf = nn.CrossEntropyLoss(); best, bad, state = -1, 0, None
        for ep in range(self.max_epochs):
            self.model.train(); perm = torch.randperm(len(yt))
            for i in range(0, len(yt), self.bs):
                b = perm[i:i + self.bs]
                if len(b) < 2: continue
                opt.zero_grad(); lossf(self.model(Xt[b]), yt[b]).backward(); opt.step()
            self.model.eval()
            with torch.no_grad(): f1 = f1_score(yv, self.model(Xv).argmax(1).numpy(), average="macro")
            sched.step(-f1)
            if f1 > best + 1e-4: best, bad, state = f1, 0, {k: v.clone() for k, v in self.model.state_dict().items()}
            else:
                bad += 1
                if bad >= self.patience: break
        self.model.load_state_dict(state); self.epochs_ = ep + 1; self.val_f1_ = best
        return self

    def predict_proba(self, X):
        torch.set_num_threads(1); self.model.eval()
        with torch.no_grad():
            return torch.softmax(self.model(torch.tensor(((X - self.mu) / self.sd).astype(np.float32))), 1).numpy()
