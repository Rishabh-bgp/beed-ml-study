"""Shared context for the extended analyses (re-uses the core package in ../../src)."""
import os, sys, pickle, json
from pathlib import Path
REV = Path(__file__).resolve().parents[1]          # extended_analyses/
os.environ.setdefault("BEED_ROOT", str(REV.parent))   # core pipeline root
sys.path.insert(0, str(REV.parent / "src"))
import numpy as np, pandas as pd
from beed import config as C, data, features, models, evaluation as E, deep
RES = REV / "results"; FIG = REV / "figures"
CACHE = REV / "results" / "_ctx_cache.pkl"
TASKS = {"4class": ([0, 1, 2, 3], {0: 0, 1: 1, 2: 2, 3: 3}), "3class": ([1, 2, 3], {1: 0, 2: 1, 3: 2})}


class Ctx:
    def __init__(self):
        if CACHE.exists():
            d = pickle.load(open(CACHE, "rb"))
            self.__dict__.update(d); return
        self.df, self.X, self.y, self.pos = data.load_beed()
        self.bonn_match, _ = data.match_to_bonn(self.X, self.y)
        self.groups = data.make_groups(self.y, self.pos, self.bonn_match)
        self.fsets = features.build_feature_sets(self.X)
        self.seg = np.array([g for g in self.groups], dtype=object)
        pickle.dump(self.__dict__, open(CACHE, "wb"))

    def task(self, name):
        cls, mp = TASKS[name]
        idx = np.where(np.isin(self.y, cls))[0]
        yt = np.full(len(self.y), -1); yt[idx] = [mp[v] for v in self.y[idx]]
        return idx, yt

    def clusters(self, size=50):
        return np.array([g if c == 0 else f"c{c}_k{p // size}" for g, c, p in zip(self.groups, self.y, self.pos)], dtype=object)


def rolling_origin_splits(ctx, idx, n=5, gap=C.GAP, seed=C.SEED):
    """Fold k: rows of each seizure class with pos in [k*400,(k+1)*400) are the test block, plus a matching
    1/5 of the Bonn segments for class 0 (fixed random partition). 50-row purge on each side of the block."""
    y, pos, groups = ctx.y, ctx.pos, ctx.groups
    rng = np.random.RandomState(seed)
    bseg = np.unique(groups[idx][y[idx] == 0]) if (y[idx] == 0).any() else np.array([])
    bseg = bseg[rng.permutation(len(bseg))]
    bfold = {g: k % n for k, g in enumerate(bseg)}
    out = []
    for k in range(n):
        te = np.zeros(len(y), bool)
        for c in np.unique(y[idx]):
            ci = idx[y[idx] == c]
            if c == 0:
                te[ci[np.array([bfold[g] == k for g in groups[ci]])]] = True
            else:
                L = len(ci); lo, hi = k * L // n, (k + 1) * L // n
                te[ci[(pos[ci] >= lo) & (pos[ci] < hi)]] = True
        tei = np.where(te)[0]
        tri = data.purge(np.setdiff1d(idx, tei), tei, y, pos, gap)
        out.append((np.sort(tri), np.sort(tei)))
    return out


def inner_blocked(ctx, tr, n_splits=3, groups=None):
    g = ctx.groups if groups is None else groups
    return data.inner_cv("blocked", ctx.y, ctx.pos, g, tr, n_splits)
