"""R2: change-point / splice analysis of BEED seizure classes 1-3 + 100/200-row boundary test."""
import numpy as np, pandas as pd, ruptures as rpt, json
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import Ctx, RES, FIG
ctx = Ctx(); X, y = ctx.X, ctx.y
rng = np.random.RandomState(42)
jumps, cps, bnd, summ = [], [], [], []
fig, axes = plt.subplots(3, 2, figsize=(16, 11), gridspec_kw={"width_ratios": [3, 2]})
for ci, c in enumerate([1, 2, 3]):
    Xc = X[y == c]; n = len(Xc)
    D = np.diff(Xc, axis=0)                       # step t -> t+1 stored at index t (between rows t and t+1)
    step = np.linalg.norm(D, axis=1)
    med = np.median(step); mad = np.median(np.abs(step - med)) * 1.4826
    # local ratio: step / median of steps in +-25 rows (excluding itself)
    loc = np.array([np.median(np.r_[step[max(0, t - 25):t], step[t + 1:t + 26]]) for t in range(len(step))])
    big = np.where((step > 8 * med) | ((step - med) / mad > 8))[0]
    for t in big:
        a, b = Xc[max(0, t - 10):t + 1], Xc[t + 1:t + 12]
        # level shift across the step: mean over 10 rows after minus before, in units of within-window SD
        lvl = np.linalg.norm(b.mean(0) - a.mean(0)) / (np.sqrt(((a.var(0) + b.var(0)) / 2).sum()) + 1e-9)
        r = np.corrcoef(Xc[t], Xc[t + 1])[0, 1]
        jumps.append({"class": c, "between_rows_pos": f"{t}->{t+1}", "pos": t, "csv_row_index": int(np.where(y == c)[0][t]),
                      "step_norm": step[t], "x_median_step": step[t] / med, "robust_z": (step[t] - med) / mad,
                      "x_local_median": step[t] / loc[t], "row_corr_across_step": r, "level_shift_sd_units": lvl,
                      "steps_gt8x_within_5_rows": int(((np.abs(big - t) <= 5)).sum()),
                      "on_100_boundary": (t + 1) % 100 == 0, "on_200_boundary": (t + 1) % 200 == 0})
    # PELT, standardised signal (mean-shift, l2) and first differences (Gaussian covariance change)
    Z = (Xc - Xc.mean(0)) / Xc.std(0); Zd = (D - D.mean(0)) / D.std(0)
    # ruptures KernelCPD = exact penalised (PELT-pruned) segmentation in C; kernel 'linear' == l2 cost
    for name, sig, model, ms in [("signal_l2", Z, "linear", 20), ("diff_l2", Zd, "linear", 20), ("diff_rbf", Zd, "rbf", 20)]:
        algo = rpt.KernelCPD(kernel=model, min_size=ms).fit(sig)
        for cmult in [1, 2, 5, 10, 20]:
            pen = cmult * (1 if model == "rbf" else sig.shape[1]) * np.log(len(sig))
            bk = algo.predict(pen=pen)[:-1]
            cps.append({"class": c, "series": name, "model": model, "penalty_mult": cmult, "penalty": pen,
                        "n_changepoints": len(bk), "changepoints_pos": json.dumps([int(b) for b in bk])})
    # boundary test at multiples of 100 / 200 rows
    for B in (100, 200):
        bt = np.arange(B - 1, n - 1, B)                 # step between pos B-1 and B, etc.
        pct = np.array([(step < step[t]).mean() for t in bt])
        rc = np.array([np.corrcoef(Xc[t], Xc[t + 1])[0, 1] for t in bt])
        allrc = np.array([np.corrcoef(Xc[t], Xc[t + 1])[0, 1] for t in range(n - 1)])
        # null: same number of randomly placed steps -> distribution of the mean percentile
        null = np.array([np.mean([(step < step[t]).mean() for t in rng.choice(n - 1, len(bt), replace=False)]) for _ in range(2000)])
        p_hi = (null >= pct.mean()).mean()
        bnd.append({"class": c, "block": B, "n_boundaries": len(bt), "mean_step_percentile": pct.mean(),
                    "max_step_percentile": pct.max(), "n_boundaries_gt_p99": int((pct > 0.99).sum()),
                    "mean_rowcorr_at_boundary": rc.mean(), "min_rowcorr_at_boundary": rc.min(),
                    "median_rowcorr_all_steps": np.median(allrc), "perm_p_boundary_steps_larger": p_hi,
                    "boundary_percentiles": json.dumps([round(float(v), 3) for v in pct]),
                    "boundary_rowcorr": json.dumps([round(float(v), 3) for v in rc])})
    summ.append({"class": c, "median_step": med, "n_steps_gt8x_median": int((step > 8 * med).sum()),
                 "n_steps_robust_z_gt8": int(((step - med) / mad > 8).sum())})
    ax = axes[ci, 0]
    for j in range(16):
        ax.plot(Z[:, j] * 0.35 + j, lw=0.5, color="k")
    for t in np.where(step > 8 * med)[0]: ax.axvline(t + 0.5, color="r", lw=0.8, alpha=0.6)
    bk = rpt.KernelCPD(kernel="linear", min_size=20).fit(Z).predict(pen=10 * 16 * np.log(n))[:-1]
    for b in bk: ax.axvline(b, color="tab:blue", ls="--", lw=1)
    ax.set_title(f"Class {c}: 16 channels (z-scored, offset); red = steps >8x median; blue dashed = PELT l2 (pen=10·d·ln n)", fontsize=9)
    ax.set_xlim(0, n); ax.set_yticks(range(16)); ax.set_yticklabels([f"X{j+1}" for j in range(16)], fontsize=6)
    ax = axes[ci, 1]
    ax.plot(step / med, lw=0.6); ax.axhline(8, color="r", ls=":")
    for t in range(199, n, 200): ax.axvline(t, color="0.6", lw=0.5)
    ax.set_yscale("log"); ax.set_title(f"Class {c}: step norm / median (red dotted = 8x; grey = 200-row boundaries)", fontsize=9)
    ax.set_xlabel("row position within class")
plt.tight_layout(); plt.savefig(FIG / "R2_changepoints.png", dpi=300); plt.close()
pd.DataFrame(jumps).to_csv(RES / "R2_large_jumps.csv", index=False)
pd.DataFrame(cps).to_csv(RES / "R2_pelt_changepoints.csv", index=False)
pd.DataFrame(bnd).to_csv(RES / "R2_boundary_test.csv", index=False)
pd.DataFrame(summ).to_csv(RES / "R2_step_summary.csv", index=False)
print(pd.DataFrame(summ)); print(pd.DataFrame(bnd).drop(columns=["boundary_percentiles", "boundary_rowcorr"]).to_string())
print(pd.DataFrame(cps)[["class", "series", "penalty_mult", "n_changepoints", "changepoints_pos"]].to_string())
print(pd.DataFrame(jumps)[["class", "pos", "x_median_step", "robust_z", "x_local_median", "row_corr_across_step", "level_shift_sd_units", "steps_gt8x_within_5_rows"]].round(2).to_string())
