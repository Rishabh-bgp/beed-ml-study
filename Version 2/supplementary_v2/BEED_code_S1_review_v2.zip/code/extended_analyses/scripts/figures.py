"""300-dpi diagnostic figures for the extended analyses (publication versions: figures_final.py)."""
import warnings; warnings.filterwarnings("ignore")
import json, glob
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from common import RES, FIG
plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False})
t4 = pd.read_csv(RES / "R1_table4_extended_cv.csv"); ra = pd.read_csv(RES / "R1_rolling_origin_summary.csv")
prim = pd.read_csv(RES / "R1_primary_model_headline.csv")
hold = pd.concat([pd.read_csv(RES / "R1_holdout_fold_scores.csv")] + ([pd.read_csv(RES / "R1_holdout_fold_scores_dq.csv")] if (RES / "R1_holdout_fold_scores_dq.csv").exists() else []) + [pd.read_csv(f) for f in glob.glob(str(RES / "R7_deep_fold_scores_part*.csv"))])
hold = hold[(hold.scheme == "holdout") & (hold.protocol == "blocked")]

# ---- Fig R1: blocked CV vs rolling origin vs single hold-out, all main + deep models
fig, axes = plt.subplots(1, 2, figsize=(11, 6.5))
for ax, task in zip(axes, ["4class", "3class"]):
    c = t4[(t4.task == task) & (t4.protocol == "blocked") & t4.family.isin(["main", "deep"])].sort_values("mean")
    p = prim[prim.task == task].iloc[0]
    for i, (_, r) in enumerate(c.iterrows()):
        lab = f"{r.model} ({r.features})"
        ax.errorbar(r["mean"], i + 0.15, xerr=r.sd, fmt="o", color="tab:blue", ms=4, capsize=2, label="5x2 purged blocked CV (mean ± SD)" if i == 0 else None)
        q = ra[(ra.task == task) & (ra.features == r.features) & (ra.model == r.model)]
        if len(q): ax.errorbar(q["mean"].iloc[0], i - 0.15, xerr=q.sd.iloc[0], fmt="s", color="tab:orange", ms=4, capsize=2, label="rolling origin, 5 test blocks (mean ± SD)" if i == 0 else None)
        h = hold[(hold.task == task) & (hold.features == r.features) & (hold.model == r.model)]
        if len(h): ax.plot(h.macro_f1.iloc[0], i, "x", color="k", ms=5, label="final-20% hold-out (single split)" if i == 0 else None)
        if r.model == p.primary_model and r.features == p.primary_features: ax.axhspan(i - 0.45, i + 0.45, color="gold", alpha=0.3, lw=0)
    ax.set_yticks(range(len(c))); ax.set_yticklabels([f"{m} ({f})" for m, f in zip(c.model, c.features)])
    ax.axvline({"4class": 0.8415, "3class": 0.7756}[task], color="r", ls=":", lw=1)
    ax.set_xlabel("macro-F1"); ax.set_title(f"{task}: leakage-aware estimates (gold = CV-selected primary;\nred dotted = best classical hold-out (test-selected) headline)", fontsize=8)
    ax.set_xlim(0.3, 1.0)
axes[0].legend(loc="lower right", fontsize=7)
plt.tight_layout(); plt.savefig(FIG / "R1_cv_rolling_holdout.png", dpi=300); plt.close()

# ---- Fig R4: fingerprint baselines
r4 = pd.read_csv(RES / "R4_fingerprint_baselines.csv")
fig, axes = plt.subplots(1, 2, figsize=(11, 5.5))
for ax, task in zip(axes, ["4class", "3class"]):
    d = r4[r4.task == task].copy(); d["lab"] = d.model + " (" + d.features + ")"
    col = {"main": "tab:blue", "deep": "tab:blue", "fingerprint": "tab:red", "normalised": "tab:green", "artefact": "0.6"}
    d = d[d.family != "artefact"]
    y = np.arange(len(d))
    ax.barh(y + 0.2, d.rolling_mean, 0.4, color=[col[f] for f in d.family], alpha=0.85, label="rolling origin mean")
    ax.barh(y - 0.2, d.holdout_blocked, 0.4, color=[col[f] for f in d.family], alpha=0.4, label="blocked hold-out")
    ax.set_yticks(y); ax.set_yticklabels(d.lab, fontsize=7); ax.invert_yaxis()
    ax.axvline(1 / {"4class": 4, "3class": 3}[task], color="k", ls=":", lw=0.8)
    ax.set_xlabel("macro-F1 (dark = rolling-origin mean, light = blocked hold-out)"); ax.set_title(f"{task}: blue = models, red = amplitude/offset fingerprints,\ngreen = after per-recording / per-row normalisation", fontsize=8)
plt.tight_layout(); plt.savefig(FIG / "R4_fingerprint_baselines.png", dpi=300); plt.close()

# ---- Fig R9: CI sensitivity
ci = pd.read_csv(RES / "R9_ci_sensitivity.csv")
fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
for ax, task in zip(axes, ["4class", "3class"]):
    d = ci[ci.task == task].reset_index(drop=True)
    for i, r in d.iterrows():
        kinds = [("naive", r.naive_lo, r.naive_hi), ("cluster 25", r.cluster25_lo, r.cluster25_hi), ("cluster 50", r.cluster50_lo, r.cluster50_hi),
                 ("cluster 100", r.cluster100_lo, r.cluster100_hi)]
        if not np.isnan(r.get("rolling_mean", np.nan)): kinds.append(("rolling ±t·SE", r.rolling_t95_lo, r.rolling_t95_hi)); kinds.append(("rolling min–max", r.rolling_min, r.rolling_max))
        for j, (k, lo, hi) in enumerate(kinds):
            yy = i * 8 + j
            ax.plot([lo, hi], [yy, yy], color=f"C{j}", lw=2, label=k if i == 0 else None)
        ax.plot(r.macro_f1, i * 8 + 1.5, "k|", ms=10)
    ax.set_yticks([i * 8 + 2.5 for i in range(len(d))]); ax.set_yticklabels([f"{r.role}\n{r.model} ({r.features})" for _, r in d.iterrows()], fontsize=6)
    ax.set_xlabel("macro-F1 (95% interval)"); ax.set_title(f"{task}: hold-out CIs by bootstrap cluster size vs rolling-origin spread", fontsize=8)
axes[1].legend(fontsize=6, loc="lower left")
plt.tight_layout(); plt.savefig(FIG / "R9_ci_sensitivity.png", dpi=300); plt.close()

# ---- Fig R6 windowed
w = pd.read_csv(RES / "R6_windowed_vs_singlerow.csv")
h = w[w.split == "holdout_final20"].iloc[0]; cvw = w[w.split == "cv5x2_blocked"]
fig, ax = plt.subplots(figsize=(6.5, 3.8))
labs = ["windowed LR\n(band power, W tuned)", "single-row SVM-RBF\nrow level", "single-row SVM-RBF\nwindow vote"]
cols = ["windowed_LR_f1", "singlerow_SVM_rowlevel_f1", "singlerow_SVM_windowvote_f1"]
cil = [json.loads(h.windowed_LR_ci_100rowclusters), json.loads(h.singlerow_rowlevel_cluster_ci), json.loads(h.singlerow_windowvote_ci)]
x = np.arange(3)
ax.bar(x - 0.2, [h[c] for c in cols], 0.4, yerr=np.array([[h[c] - lo, hi - h[c]] for c, (lo, hi) in zip(cols, cil)]).T, capsize=3, label="final-20% hold-out (95% CI)", color="tab:purple", alpha=0.8)
ax.bar(x + 0.2, [cvw[c].mean() for c in cols], 0.4, yerr=[cvw[c].std() for c in cols], capsize=3, label="5x2 purged blocked CV (mean ± SD)", color="tab:gray")
ax.set_xticks(x); ax.set_xticklabels(labs); ax.set_ylim(0, 1.05); ax.set_ylabel("macro-F1 (3-class)"); ax.legend(fontsize=7, loc="lower right")
ax.set_title("R6: windowed vs single-row models on identical rows and splits", fontsize=8)
plt.tight_layout(); plt.savefig(FIG / "R6_windowed_vs_singlerow.png", dpi=300); plt.close()

# ---- Fig R7 deep tuned vs default
p7 = RES / "R7_deep_tuned_vs_default.csv"
if p7.exists():
    d7 = pd.read_csv(p7)
    fig, ax = plt.subplots(figsize=(7, 3.8)); xl = []
    for i, (_, r) in enumerate(d7.iterrows()):
        ax.bar(i - 0.27, r.original_default_holdout, 0.27, color="0.7", label="fixed defaults, hold-out" if i == 0 else None)
        ax.bar(i, r.tuned_holdout_mean, 0.27, color="tab:blue", label="tuned, hold-out" if i == 0 else None)
        ax.bar(i + 0.27, r.tuned_cv_mean, 0.27, yerr=r.tuned_cv_sd, capsize=2, color="tab:cyan", label="tuned, blocked CV mean ± SD" if i == 0 else None)
        xl.append(f"{r.model}\n{r.task}")
    ax.set_xticks(range(len(d7))); ax.set_xticklabels(xl, fontsize=7); ax.set_ylabel("macro-F1 (blocked)"); ax.legend(fontsize=6)
    ax.set_title("Deep models with an inner-blocked grid vs fixed defaults", fontsize=8)
    plt.tight_layout(); plt.savefig(FIG / "R7_deep_tuned_vs_default.png", dpi=300); plt.close()

# ---- Fig R5 scan
s5 = RES / "r5_chbmit_scan.csv"
if s5.exists():
    sc = pd.read_csv(s5); sc = sc[sc["query"] != "ERROR"]
    pc = pd.read_csv(RES / "r5_positive_control.csv")
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.5))
    for ax, mode in zip(axes, ["perm_robust", "same_order16"]):
        d = sc[sc["mode"] == mode]
        for q, dd in d.groupby("query"): ax.hist(dd.peak_exact, bins=40, histtype="step", label=q)
        ax.axvline(0.8, color="r", ls="--", lw=1)
        if mode == "perm_robust":
            hit = pc[pc.injected_class == pc["query"].str[1].astype(int)]
            for v in hit.peak: ax.axvline(v, color="g", lw=1.5)
        ax.set_xlabel("peak normalised cross-correlation (per file)"); ax.set_ylabel("files"); ax.set_xlim(0, 1.05)
        ax.set_title(f"CHB-MIT scan, {mode} ({d.record.nunique()} files); red = 0.8 threshold" + ("; green = injected positive controls" if mode == "perm_robust" else ""), fontsize=7)
        ax.legend(fontsize=5)
    plt.tight_layout(); plt.savefig(FIG / "R5_chbmit_scan.png", dpi=300); plt.close()

# ---- Fig R8 footprint
p8 = RES / "R8_computational_footprint.csv"
if p8.exists():
    d8 = pd.read_csv(p8)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    y = np.arange(len(d8))
    axes[0].barh(y, d8.feature_extraction_ms_median, color="tab:orange", label="feature extraction / standardisation")
    axes[0].barh(y, d8.inference_ms_median_python, left=d8.feature_extraction_ms_median, color="tab:blue", label="inference (Python)")
    axes[0].plot(d8.inference_ms_median_onnxruntime + d8.feature_extraction_ms_median, y, "k|", ms=10, label="total with ONNX Runtime inference")
    axes[0].set_xscale("log"); axes[0].set_yticks(y); axes[0].set_yticklabels(d8.model, fontsize=7); axes[0].set_xlabel("median single-sample latency (ms, 1 thread, server Xeon VM)"); axes[0].legend(fontsize=6)
    sz = d8.size_onnx_kB
    axes[1].barh(y, sz, color="tab:green"); axes[1].set_yticks(y); axes[1].set_yticklabels([]); axes[1].set_xscale("log"); axes[1].set_xlabel("serialised ONNX size (kB)")
    for yi, f in zip(y, d8.macro_f1_blocked_test): axes[1].text(axes[1].get_xlim()[1], yi, f" F1 {f:.3f}", va="center", fontsize=6)
    plt.tight_layout(); plt.savefig(FIG / "R8_computational_footprint.png", dpi=300); plt.close()
print("figures written")
