"""R5: scan CHB-MIT (PhysioNet open-access mirror on AWS S3) for the source of BEED classes 1-3.

Method (tolerant to unknown per-channel gain/offset and channel permutation):
  * Queries: for each BEED seizure class c in {1,2,3}, rows 900-1099 (200 rows = 0.78 s at 256 Hz),
    first differences (199 samples x 16 channels), z-scored per channel.
  * For every CHB-MIT EDF file: first differences of every signal; normalised cross-correlation (NCC)
    of each query channel j with each file channel k at every lag (FFT, exact sliding-window norm).
    Permutation-robust score(lag) = mean_j max_k NCC_jk(lag).  Same-order score(lag) = mean_j NCC_jj(lag)
    using the first 16 file channels (CHB-MIT double-banana order), for 2 further query windows per
    class (rows 300-499, 1500-1699).
  * Record peak scores per file/query; a candidate is any score >= 0.80; a candidate would then be
    confirmed exactly by least-squares rescaling (integer gain/offset) of the raw signal.
Windows whose first-difference SD < 0.5 digital units (flat/saturated) are excluded (NCC set to 0).
Files are streamed (download -> scan -> delete); seizure-containing records are scanned first.
"""
import os, sys, time, csv, urllib.request, urllib.parse, traceback
import numpy as np
import pandas as pd
from multiprocessing import Pool
from scipy import fft as sfft
sys.path.insert(0, os.path.dirname(__file__))
import edf

BASE = "https://physionet-open.s3.amazonaws.com/chbmit/1.0.0/"
from pathlib import Path
_EA = Path(__file__).resolve().parents[1]
OUT = str(_EA / "results" / "r5_chbmit_scan.csv")
TMP = "/tmp/chbscan"; os.makedirs(TMP, exist_ok=True)
TIME_BOX_S = float(os.environ.get("R5_TIMEBOX", 75 * 60))
L = 200

d = pd.read_csv(_EA.parent / "data" / "BEED_Data.csv"); X = d.iloc[:, :16].to_numpy(float); y = d.y.to_numpy()
def query(c, s):
    q = np.diff(X[y == c][s:s + L], axis=0)
    return (q - q.mean(0)) / (q.std(0) + 1e-9)
QP = {f"c{c}_r900": query(c, 900) for c in (1, 2, 3)}                         # permutation-robust
QS = {f"c{c}_r{s}": query(c, s) for c in (1, 2, 3) for s in (300, 900, 1500)}  # same-order
LQ = L - 1

def sliding_sd(s, n):
    c1 = np.concatenate([[0], np.cumsum(s, dtype=np.float64)]); c2 = np.concatenate([[0], np.cumsum(s.astype(np.float64) ** 2)])
    m = (c1[n:] - c1[:-n]) / n; v = (c2[n:] - c2[:-n]) / n - m ** 2
    return np.sqrt(np.maximum(v, 1e-12))

def scan_file(rec):
    t0 = time.time(); path = os.path.join(TMP, rec.replace("/", "_"))
    try:
        urllib.request.urlretrieve(BASE + urllib.parse.quote(rec), path)
        e = edf.read_edf(path)
        keep = [k for k, lab in enumerate(e["labels"]) if lab not in ("-", "", ".") and e["fs"][k] == 256
                and not lab.upper().startswith(("ECG", "VNS", "EKG", "LOC", "ROC", "EMG"))]
        S = np.array([np.diff(e["sig"][k].astype(np.float32)) for k in keep])
        N = S.shape[1]; nfft = sfft.next_fast_len(N + LQ)
        Sf = sfft.rfft(S, nfft, axis=1, workers=1)
        nlag = N - LQ + 1
        sd = np.array([sliding_sd(s, LQ) for s in S])            # (K, nlag)
        sd[sd < 0.5] = np.inf   # flat / near-constant windows (digital units) are invalid -> NCC 0
        rows = []
        for qn, Q in QP.items():
            acc = np.zeros(nlag, np.float32)
            for j in range(16):
                qf = np.conj(sfft.rfft(Q[:, j].astype(np.float32), nfft))
                cc = sfft.irfft(Sf * qf[None, :], nfft, axis=1, workers=1)[:, :nlag] / (LQ * sd)
                acc += cc.max(0)
            acc /= 16; lag = int(acc.argmax())
            W = S[:, lag:lag + LQ].astype(np.float64); W = (W - W.mean(1, keepdims=True)) / (W.std(1, keepdims=True) + 1e-12)
            ex = float(np.mean([(W @ Q[:, j] / LQ).max() for j in range(16)]))
            rows.append(dict(record=rec, query=qn, mode="perm_robust", peak=float(acc[lag]), peak_exact=ex, lag=lag,
                             p999=float(np.quantile(acc, 0.999)), n_ch=len(keep), n_samples=N + 1))
        lab16 = [e["labels"][k] for k in keep[:16]]
        for qn, Q in QS.items():
            num = np.zeros(nfft, np.complex64)
            acc = np.zeros(nlag, np.float64)
            for j in range(min(16, len(keep))):
                qf = np.conj(sfft.rfft(Q[:, j].astype(np.float32), nfft))
                acc += sfft.irfft(Sf[j] * qf, nfft)[:nlag] / (LQ * sd[j])
            acc /= 16; lag = int(acc.argmax())
            W = S[:16, lag:lag + LQ].astype(np.float64); W = (W - W.mean(1, keepdims=True)) / (W.std(1, keepdims=True) + 1e-12)
            ex = float(np.mean([(W[j] @ Q[:, j]) / LQ for j in range(W.shape[0])]))
            rows.append(dict(record=rec, query=qn, mode="same_order16", peak_exact=ex, peak=float(acc[lag]), lag=lag,
                             p999=float(np.quantile(acc, 0.999)), n_ch=len(keep), n_samples=N + 1,
                             ch_order="|".join(lab16)))
        for r in rows: r["seconds"] = round(time.time() - t0, 1)
        return rows
    except Exception as ex:
        return [dict(record=rec, query="ERROR", mode=str(ex)[:200], peak=np.nan)]
    finally:
        if os.path.exists(path): os.remove(path)

if __name__ == "__main__":
    allr = [l.strip() for l in open(_EA / "notes" / "chbmit_RECORDS.txt") if l.strip()]
    sz = [l.strip() for l in open(_EA / "notes" / "chbmit_RECORDS-WITH-SEIZURES.txt") if l.strip()]
    order = sz + [r for r in allr if r not in set(sz)]
    done = set()
    if os.path.exists(OUT):
        done = set(pd.read_csv(OUT).record)
    order = [r for r in order if r not in done]
    nw = int(os.environ.get("R5_WORKERS", 4))
    start = time.time(); first = not os.path.exists(OUT)
    fields = ["record", "query", "mode", "peak", "peak_exact", "lag", "p999", "n_ch", "n_samples", "seconds", "ch_order"]
    with Pool(nw) as pool, open(OUT, "a", newline="") as fh:
        w = csv.DictWriter(fh, fields, extrasaction="ignore")
        if first: w.writeheader()
        n = 0
        for rows in pool.imap_unordered(scan_file, order):
            for r in rows: w.writerow(r)
            fh.flush(); n += 1
            best = max([r.get("peak", 0) or 0 for r in rows])
            print(f"{n}/{len(order)} {rows[0]['record']} best={best:.3f} t={time.time()-start:.0f}s", flush=True)
            if time.time() - start > TIME_BOX_S:
                print("TIME BOX REACHED", flush=True); pool.terminate(); break
