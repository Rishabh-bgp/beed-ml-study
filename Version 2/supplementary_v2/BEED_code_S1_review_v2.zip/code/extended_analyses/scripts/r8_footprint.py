"""R8 (option b): computational footprint on a server CPU (NOT edge hardware), 4-class blocked hold-out.
Tuned models (LightGBM raw+eng tuned by inner purged blocked CV; deep models with the R7 inner-blocked grid)
plus the untuned fixed defaults for disclosure. Serialised sizes, parameter/node counts, and single-sample
latency split into feature extraction and inference (Python/NumPy and ONNX Runtime, 1 thread)."""
import warnings; warnings.filterwarnings("ignore")
import os, json, time, io, tempfile, platform, subprocess
os.environ["OMP_NUM_THREADS"] = "1"
import numpy as np, pandas as pd, joblib, torch
from sklearn.base import clone
from sklearn.model_selection import GridSearchCV
from lightgbm import LGBMClassifier
from common import *
import deep2
from r7_deep import fit_cfg

torch.set_num_threads(1)
ctx = Ctx(); X, y, pos, G = ctx.X, ctx.y, ctx.pos, ctx.groups
idx, yt = ctx.task("4class"); dev, te = data.holdout("blocked", y, pos, G, idx)
F = ctx.fsets["raw+eng"].values; NF = F.shape[1]; NENG = ctx.fsets["eng"].shape[1]
TMP = Path(tempfile.mkdtemp())
x1 = X[te[:1]]
cpu = subprocess.run("lscpu | grep 'Model name'", shell=True, capture_output=True, text=True).stdout.split(":")[-1].strip()


def lat(fn, arg, n=500, warm=30):
    for _ in range(warm): fn(arg)
    ts = []
    for _ in range(n):
        t = time.perf_counter(); fn(arg); ts.append(time.perf_counter() - t)
    return 1000 * float(np.median(ts)), 1000 * float(np.percentile(ts, 95))


def fsize(p): return os.path.getsize(p) / 1024


def feat_one(x):
    return np.c_[x, features.engineered(x).values]


def feat_numpy_fast(x):
    """vectorised NumPy-only subset is not equivalent; we time the study's own extractor (Python + antropy)."""
    return feat_one(x)


rows = []
# ---- feature extraction cost (same for every model on raw+eng)
fe_med, fe_p95 = lat(feat_one, x1, n=300)
t = time.perf_counter(); features.engineered(X[te]); fe_batch = 1000 * (time.perf_counter() - t) / len(te)
std_med, _ = lat(lambda x: (x - 1.0) / 2.0, x1)

# ---- LightGBM: tuned (inner purged blocked CV, core-pipeline grid) and fixed default
inner = data.inner_cv("blocked", y, pos, G, dev, 3)
est, grid = models.get_models()["LightGBM"]
gs = GridSearchCV(clone(est), grid, cv=inner, scoring="f1_macro", n_jobs=1).fit(F[dev], yt[dev])
lgb_t = gs.best_estimator_
lgb_d = LGBMClassifier(n_estimators=300, num_leaves=31, learning_rate=0.1, subsample=0.8, subsample_freq=1,
                       colsample_bytree=0.8, n_jobs=1, random_state=C.SEED, verbose=-1).fit(F[dev], yt[dev])
import onnxruntime as ort
so = ort.SessionOptions(); so.intra_op_num_threads = 1; so.inter_op_num_threads = 1
for name, m, params in [("LightGBM (tuned)", lgb_t, gs.best_params_), ("LightGBM (original default, Table 5)", lgb_d, {"num_leaves": 31, "learning_rate": 0.1})]:
    m.set_params(n_jobs=1)
    jp = TMP / "lgb.joblib"; joblib.dump(m, jp); tp = TMP / "lgb.txt"; m.booster_.save_model(str(tp))
    nodes = m.booster_.trees_to_dataframe().shape[0]
    f1v = F[te[:1]]
    inf_med, inf_p95 = lat(m.predict_proba, f1v)
    # ONNX
    try:
        from onnxmltools import convert_lightgbm
        from onnxmltools.convert.common.data_types import FloatTensorType
        on = convert_lightgbm(m, initial_types=[("x", FloatTensorType([None, NF]))], zipmap=False, target_opset=15)
        op = TMP / "lgb.onnx"; open(op, "wb").write(on.SerializeToString())
        sess = ort.InferenceSession(str(op), so); inp = sess.get_inputs()[0].name
        onnx_med, _ = lat(lambda v: sess.run(None, {inp: v}), f1v.astype(np.float32))
        p_onnx = sess.run(None, {inp: F[te].astype(np.float32)})[1]; agree = float((p_onnx.argmax(1) == m.predict(F[te])).mean())
        onnx_kb = fsize(op)
    except Exception as ex:
        onnx_med, onnx_kb, agree = np.nan, np.nan, str(ex)[:80]
    rows.append({"model": name, "input": f"raw+engineered ({NF} = 16 raw + {NENG} engineered)", "hyperparameters": json.dumps(params),
                 "n_params_or_nodes": f"{nodes} tree nodes", "size_joblib_kB": fsize(jp), "size_native_txt_kB": fsize(tp),
                 "size_onnx_kB": onnx_kb, "feature_extraction_ms_median": fe_med, "feature_extraction_ms_p95": fe_p95,
                 "feature_extraction_ms_batched_per_row": fe_batch,
                 "inference_ms_median_python": inf_med, "inference_ms_p95_python": inf_p95, "inference_ms_median_onnxruntime": onnx_med,
                 "total_ms_median_python": fe_med + inf_med, "onnx_pred_agreement": agree,
                 "macro_f1_blocked_test": E.metrics(yt[te], m.predict(F[te]))["macro_f1"]})
    print(rows[-1], flush=True)

# ---- deep models: tuned config from R7 (holdout, 4class) and fixed defaults
import glob
r7 = pd.concat([pd.read_csv(f) for f in glob.glob(str(RES / "R7_deep_fold_scores_part*.csv"))])
for arch in ["MLP", "1D-CNN", "BiLSTM", "Transformer"]:
    sel = r7[(r7.task == "4class") & (r7.scheme == "holdout") & (r7.model == arch)]
    cfgs = [("tuned", json.loads(sel.chosen.iloc[0]))] if len(sel) else []
    cfgs.append(("original default", deep2.DEFAULT[arch]))
    for tag, cfg in cfgs:
        if tag == "original default":
            # reproduce the fixed-default training regime (60 epochs, patience 8) for disclosure
            from beed import experiments as EXP
            from types import SimpleNamespace
            mo = EXP.fit_deep(arch, X, yt, dev, "blocked", SimpleNamespace(pos=pos, groups=G), 4, threads=1)
            net, mu, sd = mo.model, mo.mu, mo.sd
        else:
            mo = fit_cfg(arch, dev, yt, 4, cfg, "blocked"); net, mu, sd = mo.model, mo.mu, mo.sd
        net.eval()
        pp = TMP / "m.pt"; torch.save(net.state_dict(), pp)
        def fwd(x):
            with torch.no_grad(): return torch.softmax(net(torch.tensor(((x - mu) / sd).astype(np.float32))), 1).numpy()
        inf_med, inf_p95 = lat(fwd, x1)
        try:
            op = TMP / "m.onnx"
            torch.onnx.export(net, torch.zeros(1, 16), str(op), input_names=["x"], output_names=["z"], dynamic_axes={"x": {0: "n"}}, dynamo=False)
            sess = ort.InferenceSession(str(op), so)
            onnx_med, _ = lat(lambda v: sess.run(None, {"x": ((v - mu) / sd).astype(np.float32)}), x1)
            agree = float((sess.run(None, {"x": ((X[te] - mu) / sd).astype(np.float32)})[0].argmax(1) == fwd(X[te]).argmax(1)).mean())
            onnx_kb = fsize(op)
        except Exception as ex:
            onnx_med, onnx_kb, agree = np.nan, np.nan, str(ex)[:80]
        npar = deep2.n_params(net)
        rows.append({"model": f"{arch} ({tag})", "input": "raw 16 values", "hyperparameters": json.dumps(cfg),
                     "n_params_or_nodes": f"{npar} parameters", "size_joblib_kB": np.nan, "size_torch_state_dict_kB": fsize(pp),
                     "size_fp32_params_kB": npar * 4 / 1024, "size_onnx_kB": onnx_kb,
                     "feature_extraction_ms_median": std_med, "inference_ms_median_python": inf_med, "inference_ms_p95_python": inf_p95,
                     "inference_ms_median_onnxruntime": onnx_med, "total_ms_median_python": inf_med, "onnx_pred_agreement": agree,
                     "macro_f1_blocked_test": E.metrics(yt[te], fwd(X[te]).argmax(1))["macro_f1"]})
        print(rows[-1], flush=True)

df = pd.DataFrame(rows); df.insert(0, "hardware", f"{cpu}, 1 thread, Python {platform.python_version()} (server VM, not edge hardware)")
df.to_csv(RES / "R8_computational_footprint.csv", index=False)
print(df.drop(columns=["hardware"]).round(4).to_string())
