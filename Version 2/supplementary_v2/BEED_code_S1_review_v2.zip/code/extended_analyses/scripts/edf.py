"""Minimal EDF reader (digital int16 samples + header) -- no external deps."""
import numpy as np

def read_edf(path):
    with open(path, 'rb') as f:
        h = f.read(256)
        ns = int(h[252:256].decode().strip())
        nrec = int(h[236:244].decode().strip())
        dur = float(h[244:252].decode().strip())
        hs = f.read(256 * ns)
        def fld(off, w):
            base = off * ns
            return [hs[base + i * w: base + (i + 1) * w].decode('latin1').strip() for i in range(ns)]
        labels = fld(0, 16)
        pmin = np.array(fld(104, 8), float); pmax = np.array(fld(112, 8), float)
        dmin = np.array(fld(120, 8), float); dmax = np.array(fld(128, 8), float)
        nsamp = np.array([int(v) for v in fld(216, 8)])
        raw = np.frombuffer(f.read(), dtype='<i2')
    rec = nsamp.sum()
    nrec = len(raw) // rec
    raw = raw[: nrec * rec].reshape(nrec, rec)
    sigs = []
    o = 0
    for k in range(ns):
        sigs.append(raw[:, o:o + nsamp[k]].reshape(-1)); o += nsamp[k]
    fs = nsamp / dur
    gain = (pmax - pmin) / (dmax - dmin)
    return dict(labels=labels, sig=sigs, fs=fs, gain=gain, pmin=pmin, dmin=dmin)
