"""R1 + R4 (+ inputs for R9): classical models, fingerprint baselines and normalised variants under
hold-out, nested purged 5x2 CV and 5-fold rolling-origin (contiguous 20% test blocks, 50-row purge).
Every fit is tuned by an inner CV that follows the outer protocol (as in the core pipeline).
Usage: python r1_classical.py <scheme> [n_jobs]   scheme in {cv, rolling, holdout}"""
import os, sys, json, time, warnings
warnings.filterwarnings("ignore")
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.base import clone
from sklearn.model_selection import GridSearchCV
from common import *

ctx = Ctx(); X, y, pos = ctx.X, ctx.y, ctx.pos
ONLY_NORM = os.environ.get("ONLY_NORM") == "1"
PRED = RES / "preds"; PRED.mkdir(exist_ok=True)

# ---------------- feature sources ----------------
def recording_std(X):
    """Per-recording channel-wise z-score. Recording = class for classes 1-3 (single recording each);
    for class 0, recording = Bonn segment. Transductive diagnostic: removes per-recording offset/scale."""
    Z = np.empty_like(X)
    keys = np.array([g if c == 0 else f"c{c}" for g, c in zip(ctx.groups, y)], dtype=object)
    for k in np.unique(keys):
        m = keys == k
        Z[m] = (X[m] - X[m].mean(0)) / (X[m].std(0) + 1e-9)
    return Z

FS = {"raw": ctx.fsets["raw"].values, "eng": ctx.fsets["eng"].values, "raw+eng": ctx.fsets["raw+eng"].values,
      "fp_absraw": np.abs(X),                                            # per-channel |x| (amplitude, no sign)
      "fp_rowsd": X.std(1, keepdims=True),                               # row SD only
      "fp_rowmean": X.mean(1, keepdims=True),                            # row mean (common offset) only
      "fp_rowstats": np.c_[X.mean(1), X.std(1), np.ptp(X, 1), np.abs(X).mean(1)],
      "recstd_raw": recording_std(X),                                    # per-recording channel z-score removed
      "rownorm_raw": (X - X.mean(1, keepdims=True)) / (X.std(1, keepdims=True) + 1e-9)}  # per-row normalisation
# NOTE: recstd_raw leaks the label through the integer lattice: (x - mu_c)/sd_c puts each class on its own value grid,
# which trees exploit (LightGBM 0.95-0.997).  The valid variants first de-quantise the integers with U(-0.5, 0.5)
# noise (fixed seed), then normalise.  recstd_raw / rownorm_raw results are kept only to document the artefact.
_XD = X + np.random.RandomState(12345).uniform(-0.5, 0.5, X.shape)
FS["recstd_dq"] = recording_std(_XD)
FS["rownorm_dq"] = (_XD - _XD.mean(1, keepdims=True)) / (_XD.std(1, keepdims=True) + 1e-9)

MAIN = {"4class": ["raw", "eng", "raw+eng"], "3class": ["raw", "raw+eng"]}
CLS = ["LR", "kNN", "SVM-RBF", "RF", "XGBoost", "LightGBM"]
FP = [(m, f) for f in ["fp_absraw", "fp_rowsd", "fp_rowmean", "fp_rowstats"] for m in ["LR", "LightGBM"]]
NORM = [(m, f) for f in ["recstd_dq", "rownorm_dq"] for m in ["LR", "kNN", "SVM-RBF", "LightGBM"]]


def configs(task, scheme, prot):
    if ONLY_NORM: return NORM
    main = [(m, f) for f in MAIN[task] for m in CLS]
    if scheme == "cv":
        # raw+eng classical CV already exists in the core pipeline (results/cv_fold_scores.csv) -> re-used, not re-run
        main = [(m, f) for (m, f) in main if f != "raw+eng"]
        return main + FP + (NORM if prot == "blocked" else [])
    return main + FP + NORM


def fit_eval(task, scheme, prot, fold, tr, te, model, fset, yt, save):
    t0 = time.time()
    F = FS[fset]
    est, grid = models.get_models()[model]
    inner = data.inner_cv(prot, y, pos, ctx.groups, tr, 3)
    if model == "SVM-RBF":
        # identical selection to the core pipeline (the f1 scorer uses predict(), i.e. the decision function,
        # which does not depend on Platt scaling), but ~5x cheaper: search with probability=False, then refit the
        # chosen parameters with probability=True (same random_state) exactly as GridSearchCV(refit=True) would.
        gs = GridSearchCV(clone(est).set_params(svc__probability=False), grid, cv=inner, scoring="f1_macro",
                          n_jobs=1, refit=False).fit(F[tr], yt[tr])
        best = clone(est).set_params(**gs.best_params_).fit(F[tr], yt[tr])
    else:
        gs = GridSearchCV(clone(est), grid, cv=inner, scoring="f1_macro", n_jobs=1, refit=True).fit(F[tr], yt[tr])
        best = gs.best_estimator_
    proba = best.predict_proba(F[te])
    n_cls = proba.shape[1]
    mm = E.metrics(yt[te], proba.argmax(1), proba, np.arange(n_cls))
    if save:
        np.savez_compressed(PRED / f"{scheme}_{task}_{prot}_{fset}_{model}_f{fold}.npz", idx=te, y=yt[te], proba=proba)
    return {"task": task, "scheme": scheme, "protocol": prot, "fold": fold, "features": fset, "model": model,
            "n_train": len(tr), "n_test": len(te), "inner_cv_f1": gs.best_score_, "best_params": json.dumps(gs.best_params_),
            "fit_seconds": time.time() - t0, **mm}


def jobs(scheme):
    J = []
    for task in ["4class", "3class"]:
        idx, yt = ctx.task(task)
        prots = ["blocked"] if scheme == "rolling" else ["blocked", "random"]
        for prot in prots:
            if scheme == "rolling":
                sp = rolling_origin_splits(ctx, idx)
            elif scheme == "cv":
                dev, _ = data.holdout(prot, y, pos, ctx.groups, idx)
                sp = data.splits(prot, y, pos, ctx.groups, dev)
            else:
                sp = [data.holdout(prot, y, pos, ctx.groups, idx)]
            for (m, f) in configs(task, scheme, prot):
                for k, (a, b) in enumerate(sp):
                    J.append((task, scheme, prot, k, a, b, m, f, yt, scheme != "cv"))
    # SVM first (longest) for better load balance
    J.sort(key=lambda j: (j[2] != "blocked", j[6] != "SVM-RBF", j[6] != "RF"))
    return J


if __name__ == "__main__":
    scheme = sys.argv[1]; nj = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    tag = sys.argv[3] if len(sys.argv) > 3 else ""
    J = jobs(scheme)
    out = RES / f"R1_{scheme}_fold_scores{tag}.csv"
    rows = []
    if out.exists():   # resume: skip fits already recorded
        prev = pd.read_csv(out); rows = prev.to_dict("records")
        done = set(zip(prev.task, prev.protocol, prev.fold, prev.features, prev.model))
        J = [j for j in J if (j[0], j[2], j[3], j[7], j[6]) not in done]
    print(scheme, len(J), "fits to run", flush=True)
    t0 = time.time()
    for i, r in enumerate(Parallel(n_jobs=nj, return_as="generator_unordered", verbose=0)(delayed(fit_eval)(*j) for j in J)):
        rows.append(r)
        if i % 3 == 0 or i == len(J) - 1:
            pd.DataFrame(rows).to_csv(out, index=False)
            print(f"{i+1}/{len(J)} {time.time()-t0:.0f}s last={r['task']},{r['protocol']},{r['features']},{r['model']} f1={r['macro_f1']:.3f}", flush=True)
    pd.DataFrame(rows).to_csv(out, index=False)
