# R2: UCI documentation of BEED, quoted verbatim

Retrieved 8 Oct 2026 (IST) from the UCI Machine Learning Repository dataset page
https://archive.ics.uci.edu/dataset/1134 (DOI 10.24432/C5K33B) and from the repository's public metadata API
(https://archive.ics.uci.edu/api/dataset?id=1134; raw response saved as `uci_beed_api.json`; page HTML saved as
`uci_beed_page.html`). Text below is copied exactly; nothing has been edited except Markdown quoting.
The dataset creators were NOT contacted (that is the author's decision).

## Abstract / summary field (verbatim)

> The Bangalore EEG Epilepsy Dataset (BEED) is a comprehensive EEG collection for epileptic seizure detection and classification. Recorded at a neurological research centre in Bangalore, India, it features high-fidelity EEG signals captured using the standard 10-20 electrode system at a 256 Hz sampling rate. BEED contains 16,000 segments of 20-second EEG recordings evenly distributed across four categories: Healthy Subjects (0), Generalized Seizures (1), Focal Seizures (2), and Seizure Events (3), where seizure activity occurs with events like eye blinking, nail biting, or staring. Each category includes data from 20 adult subjects (ages 21-55) with equal gender representation. The dataset comprises 16 EEG channels (X1-X16) corresponding to different brain regions, with a binary label (y) indicating seizure presence (1) or absence (0). BEED supports machine learning in seizure detection, epilepsy analysis, and EEG research with its balanced, high-resolution data.

## "Additional Variable Information" field (verbatim)

```
Dataset Details
Dataset Characteristics: Multivariate
Feature Type: Integer
Subject Area: Health and Medicine
Instances: 8,000 (2,000 per category)
Classes: 4
Format: CSV
Features: 16 (EEG channels)
Associated Tasks: Classification
No missing Values

Data Structure
•	Subjects: 80 individuals (20 per file across four folders)
•	Time Points: 200 per subject
•	Explanatory Variables (X1–X16): 16 features representing EEG signal characteristics
•	Response Variable (y) (Column 17): Categorizes the EEG recordings into four distinct classes:
o	3 – Recording of seizure events (including activities such as eye blinking or constant staring)
o	2 – Recording of focal seizures
o	1 – Recording of generalized seizures
o	0 – Recording of healthy subjects (control group without epileptic seizures)

```

## Other metadata fields (verbatim values)

- Name: "BEED: Bangalore EEG Epilepsy Dataset "
- Instances: 8000; Features: 17 (page: "# Instances 8000", "# Features 17")
- Feature type (page): "Integer"; Has missing values: "No"
- Variables table: X1 ... X16 and y, role "Feature", type "Integer", description/units empty
- Introductory paper: "Feature Engineering for Epileptic Seizure Classification Using SeqBoostNet", Najmusseher; P.K. Nizar Banu, International Journal of Computing and Digital Systems, 2024
- Last updated: Fri Jul 25 2025
- File: "BEED_Data.csv" (394.9 KB)
- Citation shown on the page: "., N. & BANU P K, N. (2024). BEED: Bangalore EEG Epilepsy Dataset  [Dataset]. UCI Machine Learning Repository. https://doi.org/10.24432/C5K33B."

## Inconsistencies between the documentation and the CSV (for §3.1)

| Documentation says | The public CSV (BEED_Data.csv, md5 490e221cea201e7af385897aa6dd91dc) has |
|---|---|
| "16,000 segments of 20-second EEG recordings" | 8,000 rows of 16 integers (the same page also says "Instances: 8,000 (2,000 per category)") |
| "a binary label (y) indicating seizure presence (1) or absence (0)" | y takes 4 values (0,1,2,3); the variable-information field also lists 4 classes |
| "Each category includes data from 20 adult subjects" / "Subjects: 80 individuals (20 per file across four folders)" | No subject identifier column. 2,000 rows per class / "200 time points per subject" would be 10 subjects per class, not 20 |
| "Time Points: 200 per subject" | No discontinuity at 200-row (or 100-row) boundaries in classes 1-3 (R2 boundary test, `results/R2_boundary_test.csv`, `R2_boundary_enrichment.csv`) |
| "256 Hz sampling rate", "16 EEG channels (X1-X16) corresponding to different brain regions" | Class 0 rows are exact 16-sample excerpts of the single-channel Bonn set-B recordings (173.61 Hz) (original provenance result) |
| "20-second" segments | 2,000 rows per class at 256 Hz would be 7.8 s if a row is one time point; a 20-s segment at 256 Hz has 5,120 samples |
